// ===============================
// Portfolio To-Do List (Week 8)
// Concepts: submit, preventDefault, input.value, trim,
// createElement, appendChild, remove, classList, localStorage
// ===============================


// ---------- 1) DOM SELECTION ----------

// Grab the form element (we listen for submit on the FORM)
const form = document.getElementById("taskForm");

// Grab the input element (we read what the user typed)
const input = document.getElementById("taskInput");

// Grab the Add button
const addBtn = document.getElementById("addBtn");

// Grab the search input
const searchInput = document.getElementById("searchInput");

// Grab the character counter
const charCounter = document.getElementById("charCounter");

// Grab the empty message
const emptyMessage = document.getElementById("emptyMessage");

// Grab the UL where tasks will be displayed
const taskList = document.getElementById("taskList");

// Grab the error message paragraph for validation feedback
const errorMessage = document.getElementById("errorMessage");

// Grab count elements so we can update totals
const totalCountEl = document.getElementById("totalCount");
const doneCountEl = document.getElementById("doneCount");

// Grab action buttons
const clearCompletedBtn = document.getElementById("clearCompleted");
const clearAllBtn = document.getElementById("clearAll");

// Grab all filter buttons (All/Active/Completed)
const filterButtons = document.querySelectorAll(".filters .btn");


// ---------- 2) APP STATE ----------

// Our tasks array will store objects like:
// { id: 123, text: "Buy milk", done: false, timestamp: "3:45 PM" }
let tasks = [];

// Track which filter is active
let currentFilter = "all";

// Track search text
let currentSearch = "";


// ---------- 3) LOCAL STORAGE HELPERS ----------

// Key name used in localStorage
const STORAGE_KEY = "portfolio_todo_tasks";

// Save tasks array into localStorage (as a string)
function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// Load tasks array from localStorage
function loadTasks() {
  const saved = localStorage.getItem(STORAGE_KEY);

  // If nothing saved, do nothing
  if (!saved) return;

  // Convert saved string back into array
  tasks = JSON.parse(saved);
}


// ---------- 4) VALIDATION HELPERS ----------

// Show an error message on the page
function showError(message) {
  errorMessage.textContent = message;
}

// Clear the error message
function clearError() {
  errorMessage.textContent = "";
}

// Get current time for timestamp
function getCurrentTimestamp() {
  const now = new Date();

  return now.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  });
}

// Check if a task already exists
function isDuplicateTask(text, currentId = null) {
  const trimmedText = text.trim().toLowerCase();

  for (const task of tasks) {
    if (task.id !== currentId && task.text.trim().toLowerCase() === trimmedText) {
      return true;
    }
  }

  return false;
}

// Update Add button and character counter
function updateInputUI() {
  addBtn.disabled = input.value.trim() === "";
  charCounter.textContent = `Characters: ${input.value.length}`;
}


// ---------- 5) RENDERING ----------

// Update Total and Completed counters
function updateCounts() {
  // Total tasks is length of tasks array
  const total = tasks.length;

  // Completed tasks = count tasks where done is true
  const completed = tasks.filter(t => t.done).length;

  // Update UI text
  totalCountEl.textContent = `Total: ${total}`;
  doneCountEl.textContent = `Completed: ${completed}`;
}

// Decide if a task should be visible based on currentFilter
function passesFilter(task) {
  if (currentFilter === "all") return true;          // show everything
  if (currentFilter === "active") return !task.done; // show only not done
  if (currentFilter === "completed") return task.done; // show only done
  return true;
}

// Decide if task matches search
function passesSearch(task) {
  if (currentSearch === "") return true;
  return task.text.toLowerCase().includes(currentSearch);
}

// Build ONE list item element for a task object
function createTaskElement(task) {
  // Create the <li>
  const li = document.createElement("li");
  li.classList.add("task-item");
  li.dataset.id = task.id; // store id on the element for easy lookup

  // Create a left-side box
  const infoBox = document.createElement("div");
  infoBox.classList.add("task-info");

  // Create the task text <span>
  const span = document.createElement("span");
  span.classList.add("task-text");
  span.textContent = task.text;

  // If done, add done class
  if (task.done) {
    span.classList.add("done");
  }

  // Toggle done when clicking the text
  span.addEventListener("click", function () {
    // Flip done value
    task.done = !task.done;

    // Toggle CSS class
    span.classList.toggle("done");

    // Save + update counts (and re-render for filter correctness)
    saveTasks();
    render();
  });

  // Create timestamp <span>
  const timeSpan = document.createElement("span");
  timeSpan.classList.add("task-time");
  timeSpan.textContent = `Added at: ${task.timestamp}`;

  // Create a container for buttons
  const btnBox = document.createElement("div");
  btnBox.classList.add("task-buttons");

  // Edit button
  const editBtn = document.createElement("button");
  editBtn.type = "button";
  editBtn.textContent = "Edit";
  editBtn.classList.add("btn", "ghost", "small");

  // Edit task on click
  editBtn.addEventListener("click", function () {
    const updatedText = prompt("Edit task:", task.text);

    // If user clicks cancel, stop
    if (updatedText === null) return;

    const trimmedText = updatedText.trim();

    // Validate
    if (trimmedText === "") {
      showError("Task cannot be empty.");
      return;
    }

    // Prevent duplicate tasks
    if (isDuplicateTask(trimmedText, task.id)) {
      showError("Task already exists.");
      return;
    }

    // Update task text
    task.text = trimmedText;

    // Save + re-render
    clearError();
    saveTasks();
    render();
  });

  // Delete button
  const delBtn = document.createElement("button");
  delBtn.type = "button";
  delBtn.textContent = "Delete";
  delBtn.classList.add("btn", "danger", "small");

  // Remove task on click
  delBtn.addEventListener("click", function () {
    // Keep only tasks that do NOT match this task id
    tasks = tasks.filter(t => t.id !== task.id);

    // Save + re-render
    saveTasks();
    render();
  });

  // Add span + timestamp + buttons to the list item
  infoBox.appendChild(span);
  infoBox.appendChild(timeSpan);

  btnBox.appendChild(editBtn);
  btnBox.appendChild(delBtn);

  li.appendChild(infoBox);
  li.appendChild(btnBox);

  return li;
}

// Render the entire list based on tasks + filter
function render() {
  // Clear the current list UI
  taskList.innerHTML = "";

  let visibleTasks = 0;

  // For each task, if it passes the filter, add it
  for (const task of tasks) {
    if (passesFilter(task) && passesSearch(task)) {
      const li = createTaskElement(task);
      taskList.appendChild(li);
      visibleTasks++;
    }
  }

  // Show or hide empty message
  if (visibleTasks === 0) {
    emptyMessage.style.display = "block";
  } else {
    emptyMessage.style.display = "none";
  }

  // Update counters every render
  updateCounts();
}


// ---------- 6) EVENTS ----------

// Handle form submission (Add task)
form.addEventListener("submit", function (event) {
  // Stop the page refresh
  event.preventDefault();

  // Read and clean input
  const text = input.value.trim();

  // Validate
  if (text === "") {
    showError("Task cannot be empty.");
    return;
  }

  // Prevent duplicate tasks
  if (isDuplicateTask(text)) {
    showError("Task already exists.");
    return;
  }

  // Clear any previous error
  clearError();

  // Create a new task object
  const newTask = {
    id: Date.now(),   // simple unique id
    text: text,       // what user typed
    done: false,      // default not completed
    timestamp: getCurrentTimestamp()
  };

  // Add it to tasks array
  tasks.push(newTask);

  // Save to localStorage
  saveTasks();

  // Clear input box
  input.value = "";

  // Update input UI
  updateInputUI();

  // Re-render list
  render();
});

// Clear error while user types (nice UX)
input.addEventListener("input", function () {
  if (input.value.trim() !== "") {
    clearError();
  }

  updateInputUI();
});

// Search while typing
searchInput.addEventListener("input", function () {
  currentSearch = searchInput.value.trim().toLowerCase();

  // If empty, reset search completely
  if (currentSearch === "") {
    currentSearch = "";
  }

  render();
});

// Clear completed tasks
clearCompletedBtn.addEventListener("click", function () {
  // Keep only tasks that are NOT done
  tasks = tasks.filter(t => !t.done);

  // Save + re-render
  saveTasks();
  render();
});

// Clear all tasks
clearAllBtn.addEventListener("click", function () {
  const confirmed = confirm("Are you sure you want to delete all tasks?");

  if (!confirmed) return;

  // Remove everything
  tasks = [];

  // Save + re-render
  saveTasks();
  render();
});

// Filter buttons (All / Active / Completed)
for (const btn of filterButtons) {
  btn.addEventListener("click", function () {
    // Read filter value from data-filter attribute
    currentFilter = btn.dataset.filter;

    // Update button highlight
    for (const b of filterButtons) {
      b.classList.remove("active");
    }
    btn.classList.add("active");

    // Re-render list with new filter
    render();
  });
}


// ---------- 7) INIT ----------

// Load saved tasks when page opens
loadTasks();

// Update button/counter on page load
updateInputUI();

// Render tasks immediately
render();